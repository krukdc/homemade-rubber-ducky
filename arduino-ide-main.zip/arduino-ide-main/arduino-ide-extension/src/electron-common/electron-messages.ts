export const SCHEDULE_DELETION_SIGNAL = 'arduino/scheduleDeletion';
